package app.novaclient.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import app.novaclient.library.Kind
import app.novaclient.minecraft.Minecraft
import app.novaclient.minecraft.MinecraftStatus

private data class Section(val title: String, val note: String, val target: Screen?)

private val sections = listOf(
    Section("Моды", "Аддоны и поведение", Screen.Library(Kind.MOD)),
    Section("Текстуры", "Ресурс-паки, скины", Screen.Library(Kind.TEXTURE)),
    Section("Шейдеры", "Материалы", Screen.Library(Kind.SHADER)),
    Section("Миры", "Копии и импорт", Screen.Library(Kind.WORLD)),
    Section("HUD", "Оверлей и редактор", Screen.Hud),
    Section("История", "Установки", Screen.History),
    Section("Настройки", "Сброс и данные", Screen.Settings),
)

@Composable
fun MainScreen(onOpen: (Screen) -> Unit) {
    val context = LocalContext.current
    var status by remember { mutableStateOf(Minecraft.detect(context)) }
    var error by remember { mutableStateOf<String?>(null) }

    // Вернулись из игры или магазина: перепроверяем установку и версию.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { status = Minecraft.detect(context) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(NovaNavy, NovaBlack)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Nova Client", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = NovaText)
        Text("Клиент для Minecraft Bedrock", color = NovaMuted)

        StatusCard(status)

        if (status.installed && status.canLaunch) {
            Button(
                onClick = {
                    error = Minecraft.launch(context).exceptionOrNull()?.let { "Не удалось запустить игру: ${it.message}" }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Запустить Minecraft", fontWeight = FontWeight.SemiBold)
            }
        } else {
            OutlinedButton(
                onClick = { Minecraft.openStore(context) },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
            ) { Text("Открыть Minecraft в магазине") }
        }

        error?.let { Text(it, color = NovaBad) }

        Text("Разделы", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = NovaText)
        sections.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { SectionCard(it, Modifier.weight(1f), onOpen) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text(
            "Все разделы работают. Ограничения Android описаны внутри разделов.",
            color = NovaMuted, fontSize = 12.sp,
        )
    }
}

@Composable
private fun StatusCard(status: MinecraftStatus) {
    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = NovaCard),
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).background(if (status.installed) NovaOk else NovaBad, CircleShape))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    if (status.installed) "Minecraft найден" else "Minecraft не установлен",
                    fontWeight = FontWeight.SemiBold, color = NovaText,
                )
                if (status.installed) {
                    Text(
                        "Версия ${status.versionName ?: "неизвестна"} (сборка ${status.versionCode})",
                        color = NovaMuted, fontSize = 13.sp,
                    )
                } else {
                    Text("Установите оригинальную игру из магазина", color = NovaMuted, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun SectionCard(section: Section, modifier: Modifier, onOpen: (Screen) -> Unit) {
    val target = section.target
    val colors = CardDefaults.cardColors(containerColor = NovaCard)
    val shape = RoundedCornerShape(18.dp)
    val body: @Composable ColumnScope.() -> Unit = {
        Column(Modifier.padding(16.dp).fillMaxWidth()) {
            Text(section.title, fontWeight = FontWeight.SemiBold, color = NovaText)
            Text(section.note, color = NovaCyan, fontSize = 12.sp)
        }
    }
    if (target != null) {
        Card(onClick = { onOpen(target) }, modifier = modifier, shape = shape, colors = colors, content = body)
    } else {
        Card(modifier = modifier.alpha(0.55f), shape = shape, colors = colors, content = body)
    }
}
