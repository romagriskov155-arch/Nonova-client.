package app.novaclient.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import app.novaclient.hud.GestureService
import app.novaclient.hud.HudStore
import app.novaclient.hud.OverlayService
import app.novaclient.minecraft.Minecraft
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun HudScreen(store: HudStore, onBack: () -> Unit, onEditor: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var hud by remember { mutableStateOf(store.load()) }
    var running by remember { mutableStateOf(OverlayService.running) }
    var overlayOk by remember { mutableStateOf(OverlayService.hasOverlayPermission(context)) }
    var usageOk by remember { mutableStateOf(OverlayService.hasUsageAccess(context)) }
    var gestureOk by remember { mutableStateOf(GestureService.instance != null) }
    var host by remember { mutableStateOf(hud.serverHost) }
    var port by remember { mutableStateOf(hud.serverPort.toString()) }
    var message by remember { mutableStateOf<String?>(null) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        running = OverlayService.running
        overlayOk = OverlayService.hasOverlayPermission(context)
        usageOk = OverlayService.hasUsageAccess(context)
        gestureOk = GestureService.instance != null
    }

    val notifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun startHud(): Boolean {
        if (!OverlayService.hasOverlayPermission(context)) {
            message = "Сначала выдайте разрешение «Поверх других приложений»."
            return false
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        OverlayService.start(context)
        running = true
        return true
    }

    fun saveServer() {
        val p = port.trim().toIntOrNull()?.takeIf { it in 1..65535 } ?: 19132
        val next = hud.copy(serverHost = host.trim(), serverPort = p)
        hud = next
        port = p.toString()
        scope.launch(Dispatchers.IO) { store.save(next) }
        message = "Сервер для пинга сохранён."
    }

    ScreenFrame("HUD", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard(
                "Оверлей показывает: CPS (касания экрана в секунду), индикатор нажатий, пинг до указанного сервера, " +
                    "время игры, часы, батарею и надписи.\\n\\n" +
                    "Координаты, здоровье, броню, эффекты, скорость и направление игра внешним программам не отдаёт. " +
                    "Их показывает аддон Nova HUD прямо в игре (кнопка ниже).\\n\\n" +
                    "FPS Android не позволяет узнать у чужого приложения, поэтому его здесь нет."
            )

            Text("1. Разрешения", color = NovaText, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            StatusRow("Поверх других приложений", overlayOk)
            if (!overlayOk) {
                Button(
                    onClick = {
                        context.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                ) { Text("Выдать разрешение") }
            }
            StatusRow("Доступ к статистике (чтобы знать, что открыт Minecraft)", usageOk)
            if (!usageOk) {
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                ) { Text("Открыть настройки доступа (необязательно)") }
                Text(
                    "Без него HUD показывается всегда, а время игры считается с момента включения HUD.",
                    color = NovaMuted, fontSize = 12.sp,
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = hud.onlyInGame,
                        onCheckedChange = {
                            val next = hud.copy(onlyInGame = it)
                            hud = next
                            scope.launch(Dispatchers.IO) { store.save(next) }
                        },
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Показывать HUD только в Minecraft", color = NovaText)
                }
            }

            Text("2. Управление", color = NovaText, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            Button(
                onClick = {
                    if (startHud()) {
                        val r = Minecraft.launch(context)
                        if (r.isFailure) message = "HUD включён, но игру запустить не удалось: ${r.exceptionOrNull()?.message}"
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
            ) { Text("Запустить Minecraft с HUD") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!running) {
                    OutlinedButton(onClick = { startHud() }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text("Включить HUD")
                    }
                } else {
                    OutlinedButton(onClick = { OverlayService.toggle(context) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text("Скрыть/показать")
                    }
                    OutlinedButton(
                        onClick = { OverlayService.stop(context); running = false },
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp),
                    ) { Text("Выключить") }
                }
            }
            Text(
                if (running) "HUD работает. Скрыть или выключить его можно и в уведомлении." else "HUD выключен.",
                color = if (running) NovaOk else NovaMuted, fontSize = 12.sp,
            )
            Button(onClick = onEditor, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)) {
                Text("Редактор HUD")
            }

            Text("Кнопки F5, Q и свои", color = NovaText, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            StatusRow("Служба жестов", gestureOk)
            if (!gestureOk) {
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                ) { Text("Открыть специальные возможности") }
                Text(
                    "Найдите «Nova Client: кнопки» и включите. На Android 13+ для приложения не из магазина сначала откройте " +
                        "Настройки → Приложения → Nova Client → ⋮ → «Разрешить ограниченные настройки». " +
                        "Служба не читает содержимое экрана, она только выполняет жесты в ваших точках.",
                    color = NovaMuted, fontSize = 12.sp,
                )
            }
            Text(
                "Кнопки включаются и настраиваются в редакторе HUD: положение, размер, цвет, действие и точка на экране игры.",
                color = NovaMuted, fontSize = 12.sp,
            )

            Text("3. Пинг до сервера", color = NovaText, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            OutlinedTextField(
                value = host, onValueChange = { host = it }, singleLine = true,
                label = { Text("Адрес сервера Bedrock") }, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = port, onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) }, singleLine = true,
                label = { Text("Порт (по умолчанию 19132)") }, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(onClick = { saveServer() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text("Сохранить сервер")
            }
            Text(
                "Измеряется задержка до этого сервера (RakNet-пинг), а не канал вашей текущей игры. " +
                    "Включите элемент «Пинг» в редакторе.",
                color = NovaMuted, fontSize = 12.sp,
            )

            Text("4. Данные игрока внутри игры", color = NovaText, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            OutlinedButton(
                onClick = {
                    scope.launch {
                        val file = withContext(Dispatchers.IO) {
                            runCatching {
                                val dir = File(context.filesDir, "library/addon").apply { mkdirs() }
                                File(dir, "NovaHUD.mcaddon").also { f ->
                                    context.assets.open("NovaHUD.mcaddon").use { i -> f.outputStream().use { i.copyTo(it) } }
                                }
                            }
                        }
                        message = file.fold(
                            onSuccess = { f ->
                                Minecraft.openInGame(context, f).fold(
                                    onSuccess = { "Аддон отправлен в Minecraft. Включите его в настройках мира (Поведение)." },
                                    onFailure = { "Minecraft не принял файл: ${it.message}" },
                                )
                            },
                            onFailure = { "Не удалось подготовить аддон: ${it.message}" },
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
            ) { Text("Установить аддон Nova HUD в игру") }
            Text(
                "Аддон показывает над хотбаром: координаты, направление, скорость, здоровье, броню, эффекты и время. " +
                    "Выключить для себя: /tag @s add nova_hud_off",
                color = NovaMuted, fontSize = 12.sp,
            )

            message?.let { Text(it, color = NovaCyan, fontSize = 12.sp) }
        }
    }
}

@Composable
private fun InfoCard(text: String) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NovaCard),
    ) { Text(text.replace("\\n", "\n"), Modifier.padding(14.dp), color = NovaMuted, fontSize = 12.sp) }
}

@Composable
private fun StatusRow(title: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(if (ok) "✓" else "✕", color = if (ok) NovaOk else NovaBad)
        Spacer(Modifier.width(8.dp))
        Text(title, color = NovaText, fontSize = 14.sp)
    }
}
