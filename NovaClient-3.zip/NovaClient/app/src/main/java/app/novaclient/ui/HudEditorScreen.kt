package app.novaclient.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import app.novaclient.hud.ActionButton
import app.novaclient.hud.ButtonAction
import app.novaclient.hud.OverlayService
import app.novaclient.minecraft.Minecraft
import app.novaclient.hud.HudDefaults
import app.novaclient.hud.HudElement
import app.novaclient.hud.HudFormat
import app.novaclient.hud.HudProfile
import app.novaclient.hud.HudSnapshot
import app.novaclient.hud.HudState
import app.novaclient.hud.HudStore
import app.novaclient.hud.HudType
import java.util.UUID
import kotlin.math.roundToInt

private val SAMPLE = HudSnapshot(
    cps = 7, dotActive = true, pingMs = 42, pingConfigured = true,
    playSeconds = 754, battery = 85, timeText = "21:30",
)
private val COLORS = listOf(0xFFFFFFFF, 0xFF38BDF8, 0xFF34D399, 0xFFFACC15, 0xFFF87171, 0xFFFB923C, 0xFFF472B6, 0xFF000000)
    .map { it.toInt() }
private val FONTS = listOf("Обычный", "Моно", "С засечками")
private const val COLS = 20
private const val ROWS = 9

@Composable
fun HudEditorScreen(store: HudStore, onBack: () -> Unit) {
    var state by remember { mutableStateOf(store.load()) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var grid by remember { mutableStateOf(true) }
    var renaming by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    // После настройки точки в игре сервис сохранил файл: подхватываем изменения.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { state = store.load() }

    fun commit(next: HudState) { state = next; store.save(next) }
    fun local(next: HudState) { state = next }
    fun mapElement(id: String, f: (HudElement) -> HudElement): HudState = state.copy(
        profiles = state.profiles.map { p ->
            if (p.id != state.activeId) p else p.copy(elements = p.elements.map { if (it.id == id) f(it) else it })
        }
    )
    fun mapProfiles(f: (List<HudProfile>) -> List<HudProfile>) = state.copy(profiles = f(state.profiles))
    fun mapButton(id: String, f: (ActionButton) -> ActionButton): HudState = state.copy(
        profiles = state.profiles.map { p ->
            if (p.id != state.activeId) p else p.copy(buttons = p.buttons.map { if (it.id == id) f(it) else it })
        }
    )

    val active = state.active
    val selected = active.elements.firstOrNull { it.id == selectedId }
    val selectedButton = active.buttons.firstOrNull { it.id == selectedId }

    fun calibrate(b: ActionButton, second: Boolean) {
        if (!OverlayService.hasOverlayPermission(context)) {
            note = "Сначала выдайте разрешение «Поверх других приложений» в разделе HUD."
            return
        }
        OverlayService.calibrate(context, b.id, second)
        note = if (Minecraft.launch(context).isSuccess) {
            "Открылась игра. Откройте экран, где видна нужная кнопка, наведите перекрестие и нажмите «Готово»."
        } else {
            "Откройте Minecraft вручную, наведите перекрестие на нужную точку и нажмите «Готово»."
        }
    }

    ScreenFrame("Редактор HUD", onBack) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                "Перетаскивайте элементы пальцем. Значения в предпросмотре условные: " +
                    "на экране игры HUD показывает настоящие данные.",
                color = NovaMuted, fontSize = 12.sp,
            )

            // ---- предпросмотр ----
            val cfg = LocalConfiguration.current
            val gameWidthDp = maxOf(cfg.screenWidthDp, cfg.screenHeightDp).toFloat()
            BoxWithConstraints(
                Modifier.fillMaxWidth().aspectRatio(20f / 9f)
                    .clip(RoundedCornerShape(12.dp)).background(Color(0xFF0A1220))
                    .border(1.dp, NovaCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
            ) {
                val density = LocalDensity.current
                val wPx = with(density) { maxWidth.toPx() }
                val hPx = with(density) { maxHeight.toPx() }
                val scale = maxWidth.value / gameWidthDp
                if (grid) {
                    Canvas(Modifier.fillMaxSize()) {
                        for (i in 1 until COLS) drawLine(Color(0x22FFFFFF), Offset(size.width * i / COLS, 0f), Offset(size.width * i / COLS, size.height))
                        for (i in 1 until ROWS) drawLine(Color(0x22FFFFFF), Offset(0f, size.height * i / ROWS), Offset(size.width, size.height * i / ROWS))
                    }
                }
                active.buttons.filter { it.enabled }.forEach { b ->
                    key("b-" + b.id) {
                        val sizeDp = (b.sizeDp * scale).coerceAtLeast(16f)
                        val isSel = b.id == selectedId
                        Box(
                            Modifier
                                .offset { IntOffset((b.x * wPx).roundToInt(), (b.y * hPx).roundToInt()) }
                                .size(sizeDp.dp)
                                .clip(CircleShape)
                                .background(Color(b.color).copy(alpha = b.opacity))
                                .border(if (isSel) 2.dp else 1.dp, if (isSel) NovaCyan else Color.White.copy(alpha = 0.6f), CircleShape)
                                .pointerInput(b.id, b.locked, wPx, hPx) {
                                    if (!b.locked) {
                                        detectDragGestures(
                                            onDragStart = { selectedId = b.id },
                                            onDragEnd = {
                                                if (grid) {
                                                    commit(mapButton(b.id) {
                                                        it.copy(
                                                            x = ((it.x * COLS).roundToInt() / COLS.toFloat()).coerceIn(0f, 0.95f),
                                                            y = ((it.y * ROWS).roundToInt() / ROWS.toFloat()).coerceIn(0f, 0.9f),
                                                        )
                                                    })
                                                } else commit(state)
                                            },
                                            onDrag = { change, drag ->
                                                change.consume()
                                                local(mapButton(b.id) {
                                                    it.copy(
                                                        x = (it.x + drag.x / wPx).coerceIn(0f, 0.95f),
                                                        y = (it.y + drag.y / hPx).coerceIn(0f, 0.9f),
                                                    )
                                                })
                                            },
                                        )
                                    }
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(b.label, color = Color.White, fontSize = (sizeDp * 0.4f).sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                active.elements.filter { it.enabled }.forEach { el ->
                    key(el.id) {
                        val family = when (el.font) { 1 -> FontFamily.Monospace; 2 -> FontFamily.Serif; else -> FontFamily.SansSerif }
                        val isSel = el.id == selectedId
                        Text(
                            text = HudFormat.text(el, SAMPLE),
                            color = Color(el.color).copy(alpha = el.opacity),
                            fontSize = (el.sizeSp * scale).coerceAtLeast(6f).sp,
                            fontFamily = family,
                            modifier = Modifier
                                .offset { IntOffset((el.x * wPx).roundToInt(), (el.y * hPx).roundToInt()) }
                                .background(Color.Black.copy(alpha = el.bgOpacity))
                                .then(if (isSel) Modifier.border(1.dp, NovaCyan) else Modifier)
                                .padding(horizontal = 3.dp, vertical = 1.dp)
                                .pointerInput(el.id, el.locked, wPx, hPx) {
                                    if (!el.locked) {
                                        detectDragGestures(
                                            onDragStart = { selectedId = el.id },
                                            onDragEnd = {
                                                if (grid) {
                                                    commit(mapElement(el.id) {
                                                        it.copy(
                                                            x = ((it.x * COLS).roundToInt() / COLS.toFloat()).coerceIn(0f, 0.98f),
                                                            y = ((it.y * ROWS).roundToInt() / ROWS.toFloat()).coerceIn(0f, 0.95f),
                                                        )
                                                    })
                                                } else commit(state)
                                            },
                                            onDrag = { change, drag ->
                                                change.consume()
                                                local(mapElement(el.id) {
                                                    it.copy(
                                                        x = (it.x + drag.x / wPx).coerceIn(0f, 0.98f),
                                                        y = (it.y + drag.y / hPx).coerceIn(0f, 0.95f),
                                                    )
                                                })
                                            },
                                        )
                                    }
                                },
                        )
                    }
                }
            }

            OutlinedButton(onClick = { grid = !grid }, shape = RoundedCornerShape(12.dp)) {
                Text(if (grid) "Сетка: включена" else "Сетка: выключена")
            }

            // ---- профили ----
            Text("Профили и пресеты", color = NovaText, fontWeight = FontWeight.SemiBold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                state.profiles.forEach { p ->
                    val on = p.id == state.activeId
                    val click = { selectedId = null; commit(state.copy(activeId = p.id)) }
                    if (on) Button(onClick = click, shape = RoundedCornerShape(12.dp)) { Text(p.name) }
                    else OutlinedButton(onClick = click, shape = RoundedCornerShape(12.dp)) { Text(p.name) }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val copy = active.copy(id = UUID.randomUUID().toString(), name = "${active.name} (копия)")
                    commit(state.copy(profiles = state.profiles + copy, activeId = copy.id))
                }, shape = RoundedCornerShape(12.dp)) { Text("＋ Копия текущего") }
                OutlinedButton(onClick = {
                    val p = HudDefaults.standard()
                    commit(state.copy(profiles = state.profiles + p, activeId = p.id))
                }, shape = RoundedCornerShape(12.dp)) { Text("＋ Стандартный") }
                OutlinedButton(onClick = {
                    val p = HudDefaults.minimal()
                    commit(state.copy(profiles = state.profiles + p, activeId = p.id))
                }, shape = RoundedCornerShape(12.dp)) { Text("＋ Минимальный") }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { renameText = active.name; renaming = true }, shape = RoundedCornerShape(12.dp)) { Text("Переименовать") }
                OutlinedButton(onClick = {
                    selectedId = null
                    commit(mapProfiles { list -> list.map { if (it.id == state.activeId) it.copy(elements = HudDefaults.elements(), buttons = HudDefaults.buttons()) else it } })
                }, shape = RoundedCornerShape(12.dp)) { Text("Сбросить профиль") }
                if (state.profiles.size > 1) {
                    OutlinedButton(onClick = {
                        val rest = state.profiles.filter { it.id != state.activeId }
                        selectedId = null
                        commit(state.copy(profiles = rest, activeId = rest.first().id))
                    }, shape = RoundedCornerShape(12.dp)) { Text("Удалить профиль") }
                }
            }

            // ---- элементы ----
            Text("Элементы", color = NovaText, fontWeight = FontWeight.SemiBold)
            active.elements.forEach { el ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = el.enabled, onCheckedChange = { on -> commit(mapElement(el.id) { it.copy(enabled = on) }) })
                    Spacer(Modifier.width(10.dp))
                    Text(
                        el.type.title,
                        color = if (el.id == selectedId) NovaCyan else NovaText,
                        modifier = Modifier.weight(1f).clickable { selectedId = el.id }.padding(vertical = 8.dp),
                    )
                }
            }

            // ---- кнопки действий ----
            Text("Кнопки действий (F5, Q и свои)", color = NovaText, fontWeight = FontWeight.SemiBold)
            Text(
                "Игра не принимает клавиши от других приложений, поэтому кнопка делает жест в заданной вами точке экрана. " +
                    "F5: наведите точку на кнопку смены камеры в игре. Q: настройте жест, которым вы выбрасываете предмет. " +
                    "Нужна служба жестов (раздел HUD).",
                color = NovaMuted, fontSize = 12.sp,
            )
            active.buttons.forEach { b ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = b.enabled, onCheckedChange = { on -> commit(mapButton(b.id) { it.copy(enabled = on) }) })
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "${b.label} · ${b.action.title}" + (if (b.targetSet) "" else " · точка не задана"),
                        color = if (b.id == selectedId) NovaCyan else NovaText,
                        modifier = Modifier.weight(1f).clickable { selectedId = b.id }.padding(vertical = 8.dp),
                    )
                }
            }
            OutlinedButton(onClick = {
                val nb = ActionButton(id = "btn-" + UUID.randomUUID().toString().take(8), label = "Кн", x = 0.8f, y = 0.7f)
                commit(mapProfiles { list -> list.map { if (it.id == state.activeId) it.copy(buttons = it.buttons + nb) else it } })
                selectedId = nb.id
            }, shape = RoundedCornerShape(12.dp)) { Text("＋ Своя кнопка") }
            note?.let { Text(it, color = NovaCyan, fontSize = 12.sp) }

            if (selectedButton != null) {
                val b = selectedButton
                Card(
                    Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NovaCard),
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Кнопка «${b.label}»", color = NovaText, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = b.label, singleLine = true, label = { Text("Надпись (до 4 символов)") },
                            onValueChange = { t -> commit(mapButton(b.id) { it.copy(label = t.take(4)) }) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Text("Размер: ${b.sizeDp.roundToInt()}", color = NovaMuted, fontSize = 12.sp)
                        Slider(
                            value = b.sizeDp, valueRange = 36f..96f,
                            onValueChange = { v -> local(mapButton(b.id) { it.copy(sizeDp = v) }) },
                            onValueChangeFinished = { commit(state) },
                        )
                        Text("Прозрачность: ${(b.opacity * 100).roundToInt()}%", color = NovaMuted, fontSize = 12.sp)
                        Slider(
                            value = b.opacity, valueRange = 0.3f..1f,
                            onValueChange = { v -> local(mapButton(b.id) { it.copy(opacity = v) }) },
                            onValueChangeFinished = { commit(state) },
                        )
                        Text("Цвет", color = NovaMuted, fontSize = 12.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            COLORS.forEach { c ->
                                Box(
                                    Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                                        .border(if (b.color == c) 3.dp else 1.dp, if (b.color == c) NovaCyan else NovaMuted, CircleShape)
                                        .clickable { commit(mapButton(b.id) { it.copy(color = c) }) },
                                )
                            }
                        }
                        Text("Что делает кнопка", color = NovaMuted, fontSize = 12.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ButtonAction.values().forEach { a ->
                                val click = {
                                    commit(mapButton(b.id) {
                                        it.copy(
                                            action = a,
                                            durationMs = when (a) { ButtonAction.TAP -> 80; ButtonAction.LONG -> 700; ButtonAction.SWIPE -> 300 },
                                        )
                                    })
                                }
                                if (b.action == a) Button(onClick = click, shape = RoundedCornerShape(12.dp)) { Text(a.title) }
                                else OutlinedButton(onClick = click, shape = RoundedCornerShape(12.dp)) { Text(a.title) }
                            }
                        }
                        if (b.action != ButtonAction.TAP) {
                            Text("Длительность: ${b.durationMs} мс", color = NovaMuted, fontSize = 12.sp)
                            Slider(
                                value = b.durationMs.toFloat(), valueRange = 100f..1500f,
                                onValueChange = { v -> local(mapButton(b.id) { it.copy(durationMs = v.roundToInt()) }) },
                                onValueChangeFinished = { commit(state) },
                            )
                        }
                        Button(onClick = { calibrate(b, false) }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                            Text(if (b.action == ButtonAction.SWIPE) "Задать начало свайпа в игре" else "Задать точку в игре")
                        }
                        Text(if (b.tx >= 0f) "Точка задана" else "Точка не задана", color = if (b.tx >= 0f) NovaOk else NovaBad, fontSize = 12.sp)
                        if (b.action == ButtonAction.SWIPE) {
                            OutlinedButton(onClick = { calibrate(b, true) }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                Text("Задать конец свайпа в игре")
                            }
                            Text(if (b.tx2 >= 0f) "Конец задан" else "Конец не задан", color = if (b.tx2 >= 0f) NovaOk else NovaBad, fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = b.locked, onCheckedChange = { on -> commit(mapButton(b.id) { it.copy(locked = on) }) })
                            Spacer(Modifier.width(10.dp))
                            Text("Закрепить на месте", color = NovaText, fontSize = 14.sp)
                        }
                        if (b.id.startsWith("btn-")) {
                            OutlinedButton(onClick = {
                                commit(mapProfiles { list -> list.map { if (it.id == state.activeId) it.copy(buttons = it.buttons.filter { x -> x.id != b.id }) else it } })
                                selectedId = null
                            }, shape = RoundedCornerShape(12.dp)) { Text("Удалить кнопку") }
                        }
                    }
                }
            }

            // ---- свойства выбранного ----
            if (selected == null && selectedButton == null) {
                Text("Нажмите на название элемента или кнопки, чтобы настроить её.", color = NovaMuted, fontSize = 12.sp)
            }
            if (selected != null) {
                Card(
                    Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NovaCard),
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(selected.type.title, color = NovaText, fontWeight = FontWeight.SemiBold)

                        if (selected.type == HudType.TEXT) {
                            OutlinedTextField(
                                value = selected.text, singleLine = true, label = { Text("Текст") },
                                onValueChange = { t -> commit(mapElement(selected.id) { it.copy(text = t.take(40)) }) },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }

                        Text("Размер: ${selected.sizeSp.roundToInt()}", color = NovaMuted, fontSize = 12.sp)
                        Slider(
                            value = selected.sizeSp, valueRange = 8f..40f,
                            onValueChange = { v -> local(mapElement(selected.id) { it.copy(sizeSp = v) }) },
                            onValueChangeFinished = { commit(state) },
                        )
                        Text("Прозрачность текста: ${(selected.opacity * 100).roundToInt()}%", color = NovaMuted, fontSize = 12.sp)
                        Slider(
                            value = selected.opacity, valueRange = 0.2f..1f,
                            onValueChange = { v -> local(mapElement(selected.id) { it.copy(opacity = v) }) },
                            onValueChangeFinished = { commit(state) },
                        )
                        Text("Прозрачность фона: ${(selected.bgOpacity * 100).roundToInt()}%", color = NovaMuted, fontSize = 12.sp)
                        Slider(
                            value = selected.bgOpacity, valueRange = 0f..0.85f,
                            onValueChange = { v -> local(mapElement(selected.id) { it.copy(bgOpacity = v) }) },
                            onValueChangeFinished = { commit(state) },
                        )

                        Text("Цвет", color = NovaMuted, fontSize = 12.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            COLORS.forEach { c ->
                                Box(
                                    Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                                        .border(if (selected.color == c) 3.dp else 1.dp, if (selected.color == c) NovaCyan else NovaMuted, CircleShape)
                                        .clickable { commit(mapElement(selected.id) { it.copy(color = c) }) },
                                )
                            }
                        }

                        Text("Шрифт", color = NovaMuted, fontSize = 12.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FONTS.forEachIndexed { i, name ->
                                val click = { commit(mapElement(selected.id) { it.copy(font = i) }) }
                                if (selected.font == i) Button(onClick = click, shape = RoundedCornerShape(12.dp)) { Text(name) }
                                else OutlinedButton(onClick = click, shape = RoundedCornerShape(12.dp)) { Text(name) }
                            }
                        }

                        if (selected.type.label.isNotEmpty()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = selected.showLabel, onCheckedChange = { on -> commit(mapElement(selected.id) { it.copy(showLabel = on) }) })
                                Spacer(Modifier.width(10.dp))
                                Text("Показывать подпись («${selected.type.label}: …»)", color = NovaText, fontSize = 14.sp)
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = selected.locked, onCheckedChange = { on -> commit(mapElement(selected.id) { it.copy(locked = on) }) })
                            Spacer(Modifier.width(10.dp))
                            Text("Закрепить на месте", color = NovaText, fontSize = 14.sp)
                        }
                    }
                }
            }
            Text("Изменения сохраняются сразу и применяются к работающему HUD.", color = NovaMuted, fontSize = 12.sp)
        }
    }

    if (renaming) {
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Название профиля") },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it.take(30) }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val name = renameText.trim().ifEmpty { active.name }
                    commit(mapProfiles { list -> list.map { if (it.id == state.activeId) it.copy(name = name) else it } })
                    renaming = false
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Отмена") } },
        )
    }
}
