package app.novaclient.hud

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer

/** Настоящий замер задержки до Bedrock-сервера: RakNet «Unconnected Ping» (UDP, порт по умолчанию 19132). */
object RakNetPing {
    private val MAGIC = intArrayOf(0x00, 0xFF, 0xFF, 0x00, 0xFE, 0xFE, 0xFE, 0xFE, 0xFD, 0xFD, 0xFD, 0xFD, 0x12, 0x34, 0x56, 0x78)
        .map { it.toByte() }.toByteArray()

    fun ping(host: String, port: Int, timeoutMs: Int = 1500): Long? = try {
        val address = InetAddress.getByName(host)
        DatagramSocket().use { socket ->
            socket.soTimeout = timeoutMs
            val buf = ByteBuffer.allocate(33)
            buf.put(1.toByte())
            buf.putLong(System.currentTimeMillis())
            buf.put(MAGIC)
            buf.putLong(0x4E6F7661L)
            val data = buf.array()
            val start = System.nanoTime()
            socket.send(DatagramPacket(data, data.size, address, port))
            val reply = DatagramPacket(ByteArray(1500), 1500)
            socket.receive(reply)
            val rtt = (System.nanoTime() - start) / 1_000_000
            if (reply.length > 0 && reply.data[0] == 0x1C.toByte()) rtt else null
        }
    } catch (e: Exception) {
        null
    }
}
