package app.novaclient.hud

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/** Полный размер экрана в пикселях (в координатах этого размера выполняются жесты). */
fun realScreenSize(context: Context): Pair<Int, Int> {
    val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    return if (Build.VERSION.SDK_INT >= 30) {
        val b = wm.maximumWindowMetrics.bounds
        b.width() to b.height()
    } else {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        dm.widthPixels to dm.heightPixels
    }
}

/**
 * Выполняет нажатия и свайпы в точках, заданных пользователем. Содержимое экрана не читает:
 * события не запрашиваются, доступ к окнам не нужен.
 */
class GestureService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GestureService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun perform(b: ActionButton, width: Int, height: Int): Boolean {
        val x1 = b.tx * width
        val y1 = b.ty * height
        val path = Path()
        path.moveTo(x1, y1)
        val duration: Long = when (b.action) {
            ButtonAction.TAP -> 50L
            ButtonAction.LONG -> b.durationMs.toLong().coerceAtLeast(100L)
            ButtonAction.SWIPE -> {
                path.lineTo(b.tx2 * width, b.ty2 * height)
                b.durationMs.toLong().coerceAtLeast(100L)
            }
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
            .build()
        return dispatchGesture(gesture, null, null)
    }
}
