package app.novaclient.library

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipInputStream

class ParseException(message: String) : Exception(message)

data class ParsedPack(
    val title: String,
    val description: String,
    val kind: Kind,
    val minEngine: List<Int>?,
    val details: List<String>,
    val icon: ByteArray?,
)

/**
 * Читает только служебные файлы архива (manifest.json, иконки, названия).
 * Ничего не распаковывает на диск, поэтому безопасно для любых архивов.
 */
object PackParser {
    private const val MAX_ENTRY = 2_000_000

    private class Scan {
        val files = HashMap<String, ByteArray>()
        val names = ArrayList<String>()
    }

    private class NonClosing(input: InputStream) : FilterInputStream(input) {
        override fun close() {}
    }

    private class PackInfo(
        val name: String,
        val description: String,
        val behavior: Boolean,
        val shader: Boolean,
        val skins: Boolean,
        val minEngine: List<Int>?,
        val version: String?,
        val icon: ByteArray?,
    )

    fun parse(file: File, ext: String): ParsedPack {
        val scan = Scan()
        try {
            ZipInputStream(FileInputStream(file).buffered()).use { scanZip(it, scan, "", 0) }
        } catch (e: ParseException) {
            throw e
        } catch (e: IOException) {
            throw ParseException("Файл повреждён или не является архивом Minecraft")
        }
        return if (ext == "mcworld") parseWorld(scan) else parsePacks(scan)
    }

    private fun scanZip(zis: ZipInputStream, scan: Scan, prefix: String, depth: Int) {
        while (true) {
            val entry = zis.nextEntry ?: break
            if (entry.isDirectory) continue
            val full = prefix + entry.name
            val lower = entry.name.lowercase()
            if (depth == 0 && (lower.endsWith(".mcpack") || lower.endsWith(".zip"))) {
                scanZip(ZipInputStream(NonClosing(zis)), scan, "$full!/", 1)
                continue
            }
            scan.names.add(full)
            if (isInteresting(entry.name)) scan.files[full] = readLimited(zis)
        }
    }

    private fun isInteresting(name: String) =
        name.endsWith("manifest.json") || name.endsWith("pack_icon.png") ||
            name.endsWith("en_US.lang") || name == "levelname.txt" || name == "world_icon.jpeg"

    private fun readLimited(input: InputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > MAX_ENTRY) throw ParseException("Слишком большой служебный файл в архиве")
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun parseWorld(scan: Scan): ParsedPack {
        if (scan.names.none { it.endsWith("level.dat") }) {
            throw ParseException("В архиве нет level.dat: это не мир Minecraft")
        }
        val title = scan.files["levelname.txt"]?.toString(Charsets.UTF_8)?.trim().orEmpty()
            .ifEmpty { "Мир без названия" }
        return ParsedPack(
            title = title,
            description = "Мир Minecraft",
            kind = Kind.WORLD,
            minEngine = null,
            details = listOf("Файлов в архиве: ${scan.names.size}"),
            icon = scan.files["world_icon.jpeg"],
        )
    }

    private fun parsePacks(scan: Scan): ParsedPack {
        val manifests = scan.files.keys.filter { it.endsWith("manifest.json") }.sorted()
        if (manifests.isEmpty()) throw ParseException("В архиве нет manifest.json: это не пакет Minecraft")
        val packs = manifests.mapNotNull { readPack(it, scan) }
        if (packs.isEmpty()) throw ParseException("Не удалось прочитать manifest.json")

        val main = packs.firstOrNull { it.behavior } ?: packs.first()
        val kind = when {
            packs.any { it.behavior } -> Kind.MOD
            packs.any { it.shader } -> Kind.SHADER
            else -> Kind.TEXTURE
        }
        val minEngine = packs.mapNotNull { it.minEngine }
            .maxWithOrNull(Comparator<List<Int>> { a, b -> Compat.compare(a, b) })
        val details = packs.map {
            val type = when {
                it.behavior -> "поведение/скрипты"
                it.shader -> "шейдеры (материалы)"
                it.skins -> "скины"
                else -> "ресурсы"
            }
            "• ${it.name}: $type, версия ${it.version ?: "?"}"
        }
        return ParsedPack(
            title = main.name,
            description = main.description,
            kind = kind,
            minEngine = minEngine,
            details = details,
            icon = main.icon ?: packs.firstNotNullOfOrNull { it.icon },
        )
    }

    private fun readPack(key: String, scan: Scan): PackInfo? {
        val prefix = key.removeSuffix("manifest.json")
        val json = try {
            JSONObject(String(scan.files[key]!!, Charsets.UTF_8).removePrefix("\uFEFF"))
        } catch (e: Exception) {
            return null
        }
        val header = json.optJSONObject("header") ?: return null
        val lang = scan.files[prefix + "texts/en_US.lang"]?.toString(Charsets.UTF_8)

        fun text(raw: String): String = if (raw.startsWith("pack.")) lookupLang(lang, raw) ?: raw else raw

        val modules = json.optJSONArray("modules")
        val types = (0 until (modules?.length() ?: 0)).mapNotNull { modules?.optJSONObject(it)?.optString("type") }
        val shader = scan.names.any {
            it.startsWith(prefix) && (it.contains("renderer/materials/") || it.endsWith(".material.bin"))
        }
        val version = ints(header.optJSONArray("version"))?.joinToString(".")
            ?: header.optString("version").ifEmpty { null }
        return PackInfo(
            name = text(header.optString("name", "Без названия")).ifBlank { "Без названия" },
            description = text(header.optString("description", "")),
            behavior = types.any { it == "data" || it == "script" },
            shader = shader,
            skins = types.contains("skin_pack"),
            minEngine = ints(header.optJSONArray("min_engine_version")),
            version = version,
            icon = scan.files[prefix + "pack_icon.png"],
        )
    }

    private fun ints(array: JSONArray?): List<Int>? =
        array?.let { a -> (0 until a.length()).map { a.optInt(it) } }?.takeIf { it.isNotEmpty() }

    private fun lookupLang(lang: String?, key: String): String? =
        lang?.lineSequence()?.map { it.trim() }?.firstOrNull { it.startsWith("$key=") }
            ?.substringAfter('=')?.substringBefore("\t#")?.trim()
}
