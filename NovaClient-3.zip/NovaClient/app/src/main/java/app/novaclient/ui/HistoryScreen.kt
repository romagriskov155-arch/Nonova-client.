package app.novaclient.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.novaclient.library.HistoryEntry
import app.novaclient.library.LibraryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun HistoryScreen(repo: LibraryRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var entries by remember { mutableStateOf(emptyList<HistoryEntry>()) }
    LaunchedEffect(Unit) { entries = withContext(Dispatchers.IO) { repo.history() } }

    ScreenFrame("История установок", onBack) {
        Text(
            "Записываются отправки файлов в Minecraft из этого приложения. " +
                "Принял ли игра файл, приложение узнать не может.",
            color = NovaMuted, fontSize = 12.sp,
        )
        if (entries.isEmpty()) {
            Text("Пока пусто.", color = NovaMuted)
        } else {
            OutlinedButton(onClick = {
                scope.launch {
                    withContext(Dispatchers.IO) { repo.clearHistory() }
                    entries = emptyList()
                }
            }, shape = RoundedCornerShape(12.dp)) { Text("Очистить историю") }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(entries) { e ->
                    Card(
                        Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaCard),
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(e.title, fontWeight = FontWeight.SemiBold, color = NovaText)
                            Text("${e.kind.label} · ${formatDate(e.time)}", color = NovaMuted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
