package app.novaclient.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.novaclient.library.Compat
import app.novaclient.library.Kind
import app.novaclient.library.LibraryItem
import app.novaclient.library.LibraryRepository
import app.novaclient.minecraft.Minecraft
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun hintFor(kind: Kind) = when (kind) {
    Kind.MOD -> "Установку выполняет сама игра: Minecraft откроет файл и импортирует его. Подключить пак к миру нужно в настройках мира."
    Kind.TEXTURE -> "Ресурс-паки и скины. После импорта включите пак в настройках игры (Глобальные ресурсы) или мира."
    Kind.SHADER -> "Шейдеры определяются по наличию материалов в паке. Поддержка зависит от версии игры и устройства."
    Kind.WORLD -> "Файлы здесь — ваши резервные копии: мир можно снова отправить в игру или сохранить копию в файлы."
}

@Composable
fun LibraryScreen(kind: Kind, repo: LibraryRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var minecraft by remember { mutableStateOf(Minecraft.detect(context)) }
    var all by remember { mutableStateOf(emptyList<LibraryItem>()) }
    var query by remember { mutableStateOf("") }
    var onlyFavorites by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<LibraryItem?>(null) }
    var pendingBackup by remember { mutableStateOf<LibraryItem?>(null) }

    LaunchedEffect(Unit) {
        minecraft = Minecraft.detect(context)
        all = withContext(Dispatchers.IO) { repo.items() }
    }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val results = withContext(Dispatchers.IO) { uris.map { repo.importFrom(it) } }
            val added = results.mapNotNull { it.getOrNull() }
            val errors = results.mapNotNull { it.exceptionOrNull()?.message }
            message = (added.map { "Добавлено: ${it.title} → ${it.kind.label}" } + errors).joinToString("\n")
            all = withContext(Dispatchers.IO) { repo.items() }
        }
    }

    val backup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val item = pendingBackup
        pendingBackup = null
        if (uri != null && item != null) scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)!!.use { out ->
                        repo.fileOf(item).inputStream().use { it.copyTo(out) }
                    }
                }
            }
            message = if (result.isSuccess) "Копия сохранена" else "Не удалось сохранить копию: ${result.exceptionOrNull()?.message}"
        }
    }

    val visible = all
        .filter { it.kind == kind }
        .filter { !onlyFavorites || it.favorite }
        .filter { query.isBlank() || it.title.contains(query.trim(), ignoreCase = true) }
        .sortedWith(compareByDescending<LibraryItem> { it.favorite }.thenByDescending { it.addedAt })

    ScreenFrame(kind.label, onBack) {
        Text(hintFor(kind), color = NovaMuted, fontSize = 12.sp)
        Button(
            onClick = { importer.launch(arrayOf("*/*")) },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(14.dp),
        ) { Text("Импорт файлов (.mcpack, .mcaddon, .mcworld)") }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Поиск по названию") }, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(onClick = { onlyFavorites = !onlyFavorites }, shape = RoundedCornerShape(12.dp)) {
            Text(if (onlyFavorites) "★ Только избранное (вкл.)" else "☆ Только избранное")
        }
        message?.let { Text(it, color = NovaCyan, fontSize = 12.sp) }

        if (visible.isEmpty()) {
            Text("Здесь пока ничего нет. Нажмите «Импорт».", color = NovaMuted)
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(visible, key = { it.id }) { item ->
                    ItemCard(
                        item = item,
                        icon = repo.iconOf(item),
                        installedVersion = minecraft.versionName,
                        canInstall = minecraft.installed,
                        onInstall = {
                            val r = Minecraft.openInGame(context, repo.fileOf(item))
                            if (r.isSuccess) {
                                message = "Отправлено в Minecraft: ${item.title}"
                                scope.launch(Dispatchers.IO) { repo.addHistory(item) }
                            } else {
                                message = "Minecraft не принял файл: ${r.exceptionOrNull()?.message}"
                            }
                        },
                        onFavorite = {
                            scope.launch {
                                withContext(Dispatchers.IO) { repo.toggleFavorite(item) }
                                all = withContext(Dispatchers.IO) { repo.items() }
                            }
                        },
                        onInfo = { info = item },
                        onBackup = { pendingBackup = item; backup.launch(item.fileName) },
                        onDelete = {
                            scope.launch {
                                withContext(Dispatchers.IO) { repo.delete(item) }
                                all = withContext(Dispatchers.IO) { repo.items() }
                                message = "Удалено из библиотеки. Уже установленное в игре удаляется в самом Minecraft: " +
                                    "Android не даёт приложениям доступ к его папкам."
                            }
                        },
                    )
                }
            }
        }
    }

    info?.let { item ->
        AlertDialog(
            onDismissRequest = { info = null },
            confirmButton = { TextButton(onClick = { info = null }) { Text("Закрыть") } },
            title = { Text(item.title) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (item.description.isNotBlank()) Text(item.description)
                    Text("Файл: ${item.fileName}")
                    Text("Размер: ${formatSize(item.sizeBytes)}")
                    Text("Добавлен: ${formatDate(item.addedAt)}")
                    item.minEngine?.let { Text("Минимальная версия игры: ${it.joinToString(".")}") }
                    item.details.forEach { Text(it) }
                }
            },
        )
    }
}

@Composable
private fun PackIcon(file: File) {
    val bitmap = remember(file.path) {
        if (file.exists()) BitmapFactory.decodeFile(file.path)?.asImageBitmap() else null
    }
    Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(NovaNavy)) {
        if (bitmap != null) Image(bitmap, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
private fun ItemCard(
    item: LibraryItem,
    icon: File,
    installedVersion: String?,
    canInstall: Boolean,
    onInstall: () -> Unit,
    onFavorite: () -> Unit,
    onInfo: () -> Unit,
    onBackup: () -> Unit,
    onDelete: () -> Unit,
) {
    val (compatText, compatOk) = Compat.check(item.minEngine, installedVersion)
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = NovaCard),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PackIcon(icon)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, fontWeight = FontWeight.SemiBold, color = NovaText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (item.description.isNotBlank()) {
                        Text(item.description, color = NovaMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    val line = if (item.kind == Kind.WORLD) formatSize(item.sizeBytes) else "${formatSize(item.sizeBytes)} · $compatText"
                    Text(
                        line, fontSize = 12.sp,
                        color = when (compatOk) { true -> NovaOk; false -> NovaBad; null -> NovaMuted },
                    )
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onInstall, enabled = canInstall, shape = RoundedCornerShape(12.dp)) { Text("Установить") }
                OutlinedButton(onClick = onFavorite, shape = RoundedCornerShape(12.dp)) { Text(if (item.favorite) "★" else "☆") }
                OutlinedButton(onClick = onInfo, shape = RoundedCornerShape(12.dp)) { Text("Инфо") }
                OutlinedButton(onClick = onBackup, shape = RoundedCornerShape(12.dp)) { Text("Копия") }
                OutlinedButton(onClick = onDelete, shape = RoundedCornerShape(12.dp)) { Text("Удалить") }
            }
        }
    }
}
