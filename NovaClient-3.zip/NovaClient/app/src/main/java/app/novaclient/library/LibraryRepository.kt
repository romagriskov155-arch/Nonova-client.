package app.novaclient.library

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Библиотека импортированных файлов и история установок. Хранится в закрытой памяти приложения. */
class LibraryRepository(private val context: Context) {
    private val root = File(context.filesDir, "library").apply { mkdirs() }
    private val indexFile = File(context.filesDir, "library.json")
    private val historyFile = File(context.filesDir, "history.json")

    fun fileOf(item: LibraryItem) = File(File(root, item.id), item.fileName)
    fun iconOf(item: LibraryItem) = File(File(root, item.id), "icon.bin")

    @Synchronized
    fun items(): List<LibraryItem> {
        val text = indexFile.takeIf { it.exists() }?.readText() ?: return emptyList()
        val array = try { JSONArray(text) } catch (e: Exception) { return emptyList() }
        return (0 until array.length()).mapNotNull { runCatching { fromJson(array.getJSONObject(it)) }.getOrNull() }
    }

    @Synchronized
    fun importFrom(uri: Uri): Result<LibraryItem> {
        val name = displayName(uri) ?: return Result.failure(Exception("Не удалось определить имя файла"))
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext !in setOf("mcpack", "mcaddon", "mcworld")) {
            return Result.failure(Exception("«$name»: нужен файл .mcpack, .mcaddon или .mcworld"))
        }
        val id = UUID.randomUUID().toString()
        val dir = File(root, id).apply { mkdirs() }
        return try {
            val safe = name.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
            val dest = File(dir, safe)
            context.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { input.copyTo(it) }
            } ?: throw ParseException("Не удалось открыть «$name»")
            val parsed = PackParser.parse(dest, ext)
            parsed.icon?.let { File(dir, "icon.bin").writeBytes(it) }
            val item = LibraryItem(
                id = id, fileName = safe, title = parsed.title, description = parsed.description,
                kind = parsed.kind, sizeBytes = dest.length(), addedAt = System.currentTimeMillis(),
                favorite = false, minEngine = parsed.minEngine, details = parsed.details,
            )
            saveItems(items() + item)
            Result.success(item)
        } catch (e: Exception) {
            dir.deleteRecursively()
            Result.failure(Exception("«$name»: ${e.message ?: "ошибка импорта"}"))
        }
    }

    @Synchronized
    fun delete(item: LibraryItem) {
        File(root, item.id).deleteRecursively()
        saveItems(items().filter { it.id != item.id })
    }

    @Synchronized
    fun toggleFavorite(item: LibraryItem) {
        saveItems(items().map { if (it.id == item.id) it.copy(favorite = !it.favorite) else it })
    }

    @Synchronized
    fun history(): List<HistoryEntry> {
        val text = historyFile.takeIf { it.exists() }?.readText() ?: return emptyList()
        val array = try { JSONArray(text) } catch (e: Exception) { return emptyList() }
        return (0 until array.length()).mapNotNull {
            runCatching {
                val o = array.getJSONObject(it)
                HistoryEntry(o.getLong("t"), o.getString("title"), Kind.valueOf(o.getString("kind")))
            }.getOrNull()
        }.sortedByDescending { it.time }
    }

    @Synchronized
    fun addHistory(item: LibraryItem) {
        val all = (history() + HistoryEntry(System.currentTimeMillis(), item.title, item.kind))
            .sortedByDescending { it.time }.take(200)
        val array = JSONArray()
        all.forEach { array.put(JSONObject().put("t", it.time).put("title", it.title).put("kind", it.kind.name)) }
        historyFile.writeText(array.toString())
    }

    @Synchronized
    fun clearHistory() { historyFile.delete() }

    private fun displayName(uri: Uri): String? =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }

    private fun saveItems(list: List<LibraryItem>) {
        val array = JSONArray()
        list.forEach { array.put(toJson(it)) }
        indexFile.writeText(array.toString())
    }

    private fun toJson(i: LibraryItem) = JSONObject()
        .put("id", i.id).put("file", i.fileName).put("title", i.title).put("desc", i.description)
        .put("kind", i.kind.name).put("size", i.sizeBytes).put("added", i.addedAt).put("fav", i.favorite)
        .put("min", i.minEngine?.let { JSONArray(it) })
        .put("details", JSONArray(i.details))

    private fun fromJson(o: JSONObject): LibraryItem {
        val min = o.optJSONArray("min")?.let { a -> (0 until a.length()).map { a.getInt(it) } }
        val details = o.optJSONArray("details")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
        return LibraryItem(
            id = o.getString("id"), fileName = o.getString("file"), title = o.getString("title"),
            description = o.optString("desc", ""), kind = Kind.valueOf(o.getString("kind")),
            sizeBytes = o.getLong("size"), addedAt = o.getLong("added"), favorite = o.optBoolean("fav", false),
            minEngine = min, details = details,
        )
    }
}
