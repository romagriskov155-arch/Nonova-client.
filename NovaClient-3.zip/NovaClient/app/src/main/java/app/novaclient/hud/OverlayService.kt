package app.novaclient.hud

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.util.TypedValue
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.Toast
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import app.novaclient.MainActivity
import app.novaclient.R
import app.novaclient.minecraft.Minecraft
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** Рисует HUD поверх Minecraft. Касания проходят сквозь оверлей в игру. */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "app.novaclient.hud.STOP"
        const val ACTION_TOGGLE = "app.novaclient.hud.TOGGLE"
        const val ACTION_CALIBRATE = "app.novaclient.hud.CALIBRATE"
        private const val CHANNEL = "hud"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, OverlayService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }

        fun toggle(context: Context) {
            if (running) context.startService(Intent(context, OverlayService::class.java).setAction(ACTION_TOGGLE))
        }

        /** Показывает перекрестие поверх любого экрана, чтобы задать точку для кнопки. */
        fun calibrate(context: Context, buttonId: String, second: Boolean) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, OverlayService::class.java).setAction(ACTION_CALIBRATE)
                    .putExtra("btn", buttonId).putExtra("second", second),
            )
        }

        fun hasOverlayPermission(context: Context) = Settings.canDrawOverlays(context)

        fun hasUsageAccess(context: Context): Boolean {
            val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var store: HudStore
    @Volatile private var state: HudState = HudDefaults.initial()
    private var container: FrameLayout? = null
    private var touchView: View? = null
    private val views = LinkedHashMap<String, TextView>()
    private val buttonViews = LinkedHashMap<String, TextView>()
    private var calibCross: View? = null
    private var calibBar: View? = null
    private var lastPress = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val cps = CpsTracker()
    private var executor: ScheduledExecutorService? = null
    @Volatile private var pingMs: Long? = null
    private var configStamp = -1L
    private var userHidden = false
    private var fgPkg: String? = null
    private var lastQuery = 0L
    private var lastFgPoll = 0L
    private var usageOk = false
    private var lastTick = 0L
    private var playMs = 0L
    private var battery: Int? = null
    private var lastBattery = 0L
    private val clockFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    private val tick = object : Runnable {
        override fun run() {
            try { update() } catch (e: Exception) { /* оверлей должен жить дальше */ }
            handler.postDelayed(this, 250)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = HudStore(this)
        createChannel()
        ensureForeground()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        try {
            addViews()
        } catch (e: Exception) {
            stopSelf()
            return
        }
        running = true
        lastTick = SystemClock.elapsedRealtime()
        startPingLoop()
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureForeground()
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE -> userHidden = !userHidden
            ACTION_CALIBRATE -> if (container != null) {
                startCalibration(intent?.getStringExtra("btn") ?: "", intent?.getBooleanExtra("second", false) ?: false)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        executor?.shutdownNow()
        try { container?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { touchView?.let { wm.removeView(it) } } catch (e: Exception) { }
        buttonViews.values.forEach { try { wm.removeView(it) } catch (e: Exception) { } }
        stopCalibration()
        super.onDestroy()
    }

    // ---------- окна ----------

    private fun addViews() {
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val c = FrameLayout(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(c, lp)
        container = c

        // Крошечное окно: Android сообщает ему о касаниях вне его (ACTION_OUTSIDE), по ним считается CPS.
        val tv = View(this)
        tv.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) cps.record()
            false
        }
        val tlp = WindowManager.LayoutParams(
            1, 1, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(tv, tlp)
        touchView = tv
    }

    private fun rebuildViews() {
        val c = container ?: return
        c.removeAllViews()
        views.clear()
        val density = resources.displayMetrics.density
        state.active.elements.filter { it.enabled }.forEach { e ->
            val tv = TextView(this).apply {
                setTextSize(TypedValue.COMPLEX_UNIT_SP, e.sizeSp)
                setTextColor(withAlpha(e.color, e.opacity))
                typeface = when (e.font) {
                    1 -> Typeface.MONOSPACE
                    2 -> Typeface.SERIF
                    else -> Typeface.SANS_SERIF
                }
                setBackgroundColor(Color.argb((e.bgOpacity * 255).toInt().coerceIn(0, 255), 0, 0, 0))
                val p = (6 * density).toInt()
                setPadding(p, p / 2, p, p / 2)
            }
            c.addView(tv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
            views[e.id] = tv
        }
    }

    private fun withAlpha(color: Int, alpha: Float) =
        Color.argb((alpha * 255).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    // ---------- обновление ----------

    private fun update() {
        val now = SystemClock.elapsedRealtime()
        val stamp = store.file.lastModified()
        if (stamp != configStamp) {
            configStamp = stamp
            state = store.load()
            rebuildViews()
            rebuildButtons()
        }

        if (state.onlyInGame && now - lastFgPoll > 1500) {
            lastFgPoll = now
            usageOk = hasUsageAccess(this)
            if (usageOk) pollForeground()
        }
        val tracking = state.onlyInGame && usageOk
        val inGame = fgPkg == Minecraft.PACKAGE
        if (!tracking || inGame) playMs += now - lastTick
        lastTick = now

        val c = container ?: return
        val visible = !userHidden && (!tracking || inGame)
        c.visibility = if (visible) View.VISIBLE else View.GONE
        buttonViews.values.forEach { it.visibility = if (visible) View.VISIBLE else View.GONE }
        if (!visible) return

        if (now - lastBattery > 5000) { battery = readBattery(); lastBattery = now }
        val w = c.width
        val h = c.height
        if (w == 0 || h == 0) return

        val snap = HudSnapshot(
            cps = cps.cps(),
            dotActive = cps.lastTouchAgoMs() < 150,
            pingMs = pingMs,
            pingConfigured = state.serverHost.isNotBlank(),
            playSeconds = playMs / 1000,
            battery = battery,
            timeText = clockFormat.format(Date()),
        )
        state.active.elements.forEach { e ->
            val tv = views[e.id] ?: return@forEach
            val text = HudFormat.text(e, snap)
            if (tv.text.toString() != text) tv.text = text
            tv.translationX = e.x * w
            tv.translationY = e.y * h
            if (e.type == HudType.CPS_DOT) tv.alpha = if (snap.dotActive) 1f else 0.3f
        }
    }

    private fun pollForeground() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastQuery == 0L) now - 24 * 3_600_000L else lastQuery
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> fgPkg = e.packageName
                UsageEvents.Event.ACTIVITY_PAUSED -> if (e.packageName == fgPkg) fgPkg = null
            }
        }
        lastQuery = now
    }

    private fun readBattery(): Int? {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) level * 100 / scale else null
    }

    private fun startPingLoop() {
        executor = Executors.newSingleThreadScheduledExecutor().also { ex ->
            ex.scheduleWithFixedDelay({
                val s = state
                val wants = s.active.elements.any { it.enabled && it.type == HudType.PING }
                pingMs = if (wants && s.serverHost.isNotBlank()) RakNetPing.ping(s.serverHost.trim(), s.serverPort) else null
            }, 1, 3, TimeUnit.SECONDS)
        }
    }

    // ---------- кнопки действий ----------

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun rebuildButtons() {
        buttonViews.values.forEach { try { wm.removeView(it) } catch (e: Exception) { } }
        buttonViews.clear()
        val (w, h) = realScreenSize(this)
        val density = resources.displayMetrics.density
        state.active.buttons.filter { it.enabled }.forEach { b ->
            val size = (b.sizeDp * density).toInt()
            val tv = TextView(this).apply {
                text = b.label
                gravity = Gravity.CENTER
                setWidth(size)
                setHeight(size)
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(withAlpha(b.color, b.opacity))
                    setStroke((2 * density).toInt(), Color.argb(160, 255, 255, 255))
                }
                setOnTouchListener { v, ev ->
                    when (ev.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { v.alpha = 0.6f; pressButton(b.id) }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
                    }
                    true
                }
            }
            val lp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT).apply {
                x = (b.x * w).toInt()
                y = (b.y * h).toInt()
            }
            try {
                wm.addView(tv, lp)
                buttonViews[b.id] = tv
            } catch (e: Exception) { }
        }
    }

    private fun pressButton(id: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastPress < 120) return
        lastPress = now
        val b = state.active.buttons.firstOrNull { it.id == id } ?: return
        if (!b.targetSet) {
            toast("Точка не задана: Редактор HUD → кнопка → «Задать точку»")
            return
        }
        val gs = GestureService.instance
        if (gs == null) {
            toast("Включите службу «Nova Client: кнопки» в Специальных возможностях")
            return
        }
        val (w, h) = realScreenSize(this)
        if (!gs.perform(b, w, h)) toast("Не удалось выполнить жест")
    }

    private class CrossView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(230, 56, 189, 248)
            style = Paint.Style.STROKE
            strokeWidth = 5f
        }

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            canvas.drawCircle(cx, cy, minOf(cx, cy) - 6f, paint)
            canvas.drawLine(cx, 0f, cx, height.toFloat(), paint)
            canvas.drawLine(0f, cy, width.toFloat(), cy, paint)
        }
    }

    private fun actionText(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.rgb(56, 189, 248))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        val p = (12 * resources.displayMetrics.density).toInt()
        setPadding(p, p, p, p)
        setOnClickListener { onClick() }
    }

    private fun startCalibration(buttonId: String, second: Boolean) {
        stopCalibration()
        val density = resources.displayMetrics.density
        val (w, h) = realScreenSize(this)
        val size = (72 * density).toInt()

        val cross = CrossView(this)
        val clp = overlayParams(size, size).apply {
            x = w / 2 - size / 2
            y = h / 2 - size / 2
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        cross.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; startX = clp.x; startY = clp.y }
                MotionEvent.ACTION_MOVE -> {
                    clp.x = (startX + (ev.rawX - downX).toInt()).coerceIn(0, w - size)
                    clp.y = (startY + (ev.rawY - downY).toInt()).coerceIn(0, h - size)
                    try { wm.updateViewLayout(v, clp) } catch (e: Exception) { }
                }
            }
            true
        }

        val hint = TextView(this).apply {
            text = if (second) "Наведите перекрестие на КОНЕЦ свайпа" else "Наведите перекрестие на нужную точку в игре"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(actionText("✓ Готово") {
                val fx = (clp.x + size / 2f) / w
                val fy = (clp.y + size / 2f) / h
                saveTarget(buttonId, second, fx, fy)
                stopCalibration()
                toast("Точка сохранена")
            })
            addView(actionText("✕ Отмена") { stopCalibration() })
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(220, 5, 8, 15))
            val pad = (10 * density).toInt()
            setPadding(pad, pad, pad, pad)
            addView(hint)
            addView(row)
        }
        val blp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (16 * density).toInt()
        }
        try {
            wm.addView(cross, clp)
            wm.addView(bar, blp)
            calibCross = cross
            calibBar = bar
        } catch (e: Exception) {
            try { wm.removeView(cross) } catch (e2: Exception) { }
        }
    }

    private fun stopCalibration() {
        calibCross?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        calibBar?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        calibCross = null
        calibBar = null
    }

    private fun saveTarget(buttonId: String, second: Boolean, fx: Float, fy: Float) {
        val s = store.load()
        val next = s.copy(profiles = s.profiles.map { p ->
            if (p.id != s.activeId) p else p.copy(buttons = p.buttons.map {
                if (it.id != buttonId) it
                else if (second) it.copy(tx2 = fx, ty2 = fy) else it.copy(tx = fx, ty = fy)
            })
        })
        store.save(next)
    }

    // ---------- уведомление ----------

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "HUD", NotificationManager.IMPORTANCE_LOW))
    }

    private fun ensureForeground() {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            flags,
        )
        val toggle = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE), flags)
        val stop = PendingIntent.getService(this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), flags)
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Nova Client: HUD включён")
            .setContentText("Нажмите, чтобы вернуться в клиент")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Скрыть/показать", toggle)
            .addAction(0, "Выключить", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
