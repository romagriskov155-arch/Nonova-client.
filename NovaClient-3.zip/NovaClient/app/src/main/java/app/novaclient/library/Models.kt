package app.novaclient.library

enum class Kind(val label: String) {
    MOD("Моды"),
    TEXTURE("Текстуры"),
    SHADER("Шейдеры"),
    WORLD("Миры"),
}

data class LibraryItem(
    val id: String,
    val fileName: String,
    val title: String,
    val description: String,
    val kind: Kind,
    val sizeBytes: Long,
    val addedAt: Long,
    val favorite: Boolean,
    val minEngine: List<Int>?,
    val details: List<String>,
)

data class HistoryEntry(val time: Long, val title: String, val kind: Kind)

object Compat {
    fun compare(a: List<Int>, b: List<Int>): Int {
        for (i in 0 until maxOf(a.size, b.size, 3)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }

    /** "1.21.50.07" -> [1, 21, 50, 7] */
    fun parseInstalled(version: String?): List<Int>? =
        version?.split('.')
            ?.mapNotNull { part -> part.takeWhile { it.isDigit() }.toIntOrNull() }
            ?.takeIf { it.size >= 2 }

    /** Текст и признак: true — совместимо, false — нужна более новая игра, null — неизвестно. */
    fun check(minEngine: List<Int>?, installedVersion: String?): Pair<String, Boolean?> {
        val installed = parseInstalled(installedVersion) ?: return "Minecraft не найден" to null
        val min = minEngine ?: return "Совместимость не указана" to null
        val need = min.take(3).joinToString(".")
        return if (compare(installed, min) >= 0) "Совместимо (нужна $need+)" to true
        else "Нужна версия $need+" to false
    }
}
