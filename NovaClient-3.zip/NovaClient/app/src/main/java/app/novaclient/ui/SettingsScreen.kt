package app.novaclient.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.novaclient.hud.HudDefaults
import app.novaclient.hud.HudStore
import app.novaclient.library.LibraryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(store: HudStore, repo: LibraryRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
    }

    ScreenFrame("Настройки", onBack) {
        Text("Nova Client, версия $version", color = NovaText)
        Text("Язык интерфейса: русский. Тема: тёмная.", color = NovaMuted, fontSize = 12.sp)
        OutlinedButton(
            onClick = {
                scope.launch {
                    withContext(Dispatchers.IO) { store.save(HudDefaults.initial()) }
                    message = "Настройки HUD сброшены: профили, позиции, сервер для пинга."
                }
            },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        ) { Text("Сбросить настройки HUD") }
        OutlinedButton(
            onClick = {
                scope.launch {
                    withContext(Dispatchers.IO) { repo.clearHistory() }
                    message = "История установок очищена."
                }
            },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        ) { Text("Очистить историю установок") }
        message?.let { Text(it, color = NovaCyan, fontSize = 12.sp) }
        Text(
            "Проверки обновлений клиента нет: у приложения нет сервера, с которого можно получать версии. " +
                "Новая версия приходит файлом и ставится поверх старой, данные сохраняются.",
            color = NovaMuted, fontSize = 12.sp,
        )
    }
}
