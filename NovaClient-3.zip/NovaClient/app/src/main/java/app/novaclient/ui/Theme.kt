package app.novaclient.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NovaBlack = Color(0xFF05080F)
val NovaNavy = Color(0xFF0B1F3F)
val NovaCard = Color(0xFF0E1A30)
val NovaCyan = Color(0xFF38BDF8)
val NovaText = Color(0xFFE6F1FF)
val NovaMuted = Color(0xFF8FA6C4)
val NovaOk = Color(0xFF34D399)
val NovaBad = Color(0xFFF87171)

private val Scheme = darkColorScheme(
    primary = NovaCyan,
    onPrimary = NovaBlack,
    background = NovaBlack,
    surface = NovaCard,
    onBackground = NovaText,
    onSurface = NovaText,
    error = NovaBad,
)

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
