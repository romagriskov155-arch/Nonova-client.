package app.novaclient.hud

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

enum class HudType(val title: String, val label: String) {
    CPS("CPS (касания в секунду)", "CPS"),
    CPS_DOT("Индикатор нажатий", ""),
    PING("Пинг до сервера", "Пинг"),
    PLAYTIME("Время игры", "Время игры"),
    CLOCK("Часы", "Время"),
    BATTERY("Батарея", "Батарея"),
    TEXT("Текстовая надпись", ""),
}

data class HudElement(
    val id: String,
    val type: HudType,
    val enabled: Boolean = false,
    val x: Float = 0.02f,
    val y: Float = 0.05f,
    val sizeSp: Float = 16f,
    val color: Int = 0xFFFFFFFF.toInt(),
    val opacity: Float = 1f,
    val bgOpacity: Float = 0.35f,
    val font: Int = 0,
    val showLabel: Boolean = true,
    val locked: Boolean = false,
    val text: String = "Nova Client",
)

enum class ButtonAction(val title: String) {
    TAP("Нажатие"),
    LONG("Удержание"),
    SWIPE("Свайп"),
}

/** Экранная кнопка: по нажатию делает жест в точке (tx, ty), заданной пользователем (доли экрана 0..1). */
data class ActionButton(
    val id: String,
    val label: String,
    val enabled: Boolean = false,
    val x: Float = 0.9f,
    val y: Float = 0.4f,
    val sizeDp: Float = 56f,
    val color: Int = 0xFF38BDF8.toInt(),
    val opacity: Float = 0.8f,
    val action: ButtonAction = ButtonAction.TAP,
    val tx: Float = -1f,
    val ty: Float = -1f,
    val tx2: Float = -1f,
    val ty2: Float = -1f,
    val durationMs: Int = 80,
    val locked: Boolean = false,
) {
    val targetSet: Boolean
        get() = tx >= 0f && ty >= 0f && (action != ButtonAction.SWIPE || (tx2 >= 0f && ty2 >= 0f))
}

data class HudProfile(
    val id: String,
    val name: String,
    val elements: List<HudElement>,
    val buttons: List<ActionButton> = HudDefaults.buttons(),
)

data class HudState(
    val profiles: List<HudProfile>,
    val activeId: String,
    val serverHost: String = "",
    val serverPort: Int = 19132,
    val onlyInGame: Boolean = true,
) {
    val active: HudProfile get() = profiles.firstOrNull { it.id == activeId } ?: profiles.first()
}

object HudDefaults {
    fun elements(): List<HudElement> = listOf(
        HudElement("cps", HudType.CPS, enabled = true, x = 0.02f, y = 0.04f),
        HudElement("dot", HudType.CPS_DOT, x = 0.02f, y = 0.13f),
        HudElement("ping", HudType.PING, x = 0.02f, y = 0.21f),
        HudElement("play", HudType.PLAYTIME, enabled = true, x = 0.02f, y = 0.29f),
        HudElement("clock", HudType.CLOCK, x = 0.88f, y = 0.04f),
        HudElement("battery", HudType.BATTERY, x = 0.84f, y = 0.13f),
        HudElement("text", HudType.TEXT, x = 0.40f, y = 0.04f),
    )

    fun buttons(): List<ActionButton> = listOf(
        ActionButton("f5", "F5", x = 0.90f, y = 0.40f),
        ActionButton("q", "Q", x = 0.90f, y = 0.56f),
    )

    fun standard() = HudProfile(UUID.randomUUID().toString(), "Стандартный", elements())

    fun minimal() = HudProfile(
        UUID.randomUUID().toString(), "Минимальный",
        elements().map { it.copy(enabled = it.type == HudType.CPS) },
    )

    fun initial(): HudState {
        val p = standard()
        return HudState(listOf(p), p.id)
    }
}

class CpsTracker {
    private val times = ArrayDeque<Long>()

    @Synchronized
    fun record() {
        val now = android.os.SystemClock.elapsedRealtime()
        times.addLast(now)
        trim(now)
    }

    @Synchronized
    fun cps(): Int {
        trim(android.os.SystemClock.elapsedRealtime())
        return times.size
    }

    @Synchronized
    fun lastTouchAgoMs(): Long =
        if (times.isEmpty()) Long.MAX_VALUE else android.os.SystemClock.elapsedRealtime() - times.last()

    private fun trim(now: Long) {
        while (times.isNotEmpty() && now - times.first() > 1000) times.removeFirst()
    }
}

data class HudSnapshot(
    val cps: Int,
    val dotActive: Boolean,
    val pingMs: Long?,
    val pingConfigured: Boolean,
    val playSeconds: Long,
    val battery: Int?,
    val timeText: String,
)

object HudFormat {
    fun text(e: HudElement, s: HudSnapshot): String {
        fun withLabel(value: String) =
            if (e.showLabel && e.type.label.isNotEmpty()) "${e.type.label}: $value" else value
        return when (e.type) {
            HudType.CPS -> withLabel(s.cps.toString())
            HudType.CPS_DOT -> "●"
            HudType.PING -> withLabel(
                when {
                    !s.pingConfigured -> "задайте сервер"
                    s.pingMs == null -> "—"
                    else -> "${s.pingMs} мс"
                }
            )
            HudType.PLAYTIME -> withLabel(duration(s.playSeconds))
            HudType.CLOCK -> withLabel(s.timeText)
            HudType.BATTERY -> withLabel(s.battery?.let { "$it%" } ?: "—")
            HudType.TEXT -> e.text
        }
    }

    fun duration(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }
}

class HudStore(context: Context) {
    val file = File(context.filesDir, "hud.json")

    fun load(): HudState {
        val text = file.takeIf { it.exists() }?.readText() ?: return HudDefaults.initial()
        return try { parse(JSONObject(text)) } catch (e: Exception) { HudDefaults.initial() }
    }

    fun save(state: HudState) {
        file.writeText(toJson(state).toString())
    }

    private fun parse(o: JSONObject): HudState {
        val arr = o.getJSONArray("profiles")
        val profiles = (0 until arr.length()).map { profileFrom(arr.getJSONObject(it)) }
        if (profiles.isEmpty()) return HudDefaults.initial()
        val active = o.optString("active")
        return HudState(
            profiles = profiles,
            activeId = if (profiles.any { it.id == active }) active else profiles.first().id,
            serverHost = o.optString("host", ""),
            serverPort = o.optInt("port", 19132),
            onlyInGame = o.optBoolean("onlyInGame", true),
        )
    }

    private fun profileFrom(o: JSONObject): HudProfile {
        val arr = o.getJSONArray("elements")
        val els = (0 until arr.length()).mapNotNull { runCatching { elementFrom(arr.getJSONObject(it)) }.getOrNull() }
        val have = els.map { it.id }.toSet()
        val buttons = o.optJSONArray("buttons")?.let { a ->
            (0 until a.length()).mapNotNull { runCatching { buttonFrom(a.getJSONObject(it)) }.getOrNull() }
        } ?: HudDefaults.buttons()
        return HudProfile(
            o.getString("id"), o.getString("name"),
            els + HudDefaults.elements().filter { it.id !in have }, buttons,
        )
    }

    private fun elementFrom(o: JSONObject) = HudElement(
        id = o.getString("id"),
        type = HudType.valueOf(o.getString("type")),
        enabled = o.optBoolean("enabled", false),
        x = o.optDouble("x", 0.02).toFloat(),
        y = o.optDouble("y", 0.05).toFloat(),
        sizeSp = o.optDouble("size", 16.0).toFloat(),
        color = o.optInt("color", 0xFFFFFFFF.toInt()),
        opacity = o.optDouble("opacity", 1.0).toFloat(),
        bgOpacity = o.optDouble("bg", 0.35).toFloat(),
        font = o.optInt("font", 0),
        showLabel = o.optBoolean("label", true),
        locked = o.optBoolean("locked", false),
        text = o.optString("text", "Nova Client"),
    )

    private fun buttonFrom(o: JSONObject) = ActionButton(
        id = o.getString("id"),
        label = o.optString("label", "?"),
        enabled = o.optBoolean("enabled", false),
        x = o.optDouble("x", 0.9).toFloat(),
        y = o.optDouble("y", 0.4).toFloat(),
        sizeDp = o.optDouble("size", 56.0).toFloat(),
        color = o.optInt("color", 0xFF38BDF8.toInt()),
        opacity = o.optDouble("opacity", 0.8).toFloat(),
        action = runCatching { ButtonAction.valueOf(o.getString("action")) }.getOrDefault(ButtonAction.TAP),
        tx = o.optDouble("tx", -1.0).toFloat(),
        ty = o.optDouble("ty", -1.0).toFloat(),
        tx2 = o.optDouble("tx2", -1.0).toFloat(),
        ty2 = o.optDouble("ty2", -1.0).toFloat(),
        durationMs = o.optInt("dur", 80),
        locked = o.optBoolean("locked", false),
    )

    private fun toJson(s: HudState): JSONObject {
        val profiles = JSONArray()
        s.profiles.forEach { p ->
            val els = JSONArray()
            p.elements.forEach { e ->
                els.put(
                    JSONObject().put("id", e.id).put("type", e.type.name).put("enabled", e.enabled)
                        .put("x", e.x.toDouble()).put("y", e.y.toDouble()).put("size", e.sizeSp.toDouble())
                        .put("color", e.color).put("opacity", e.opacity.toDouble()).put("bg", e.bgOpacity.toDouble())
                        .put("font", e.font).put("label", e.showLabel).put("locked", e.locked).put("text", e.text)
                )
            }
            val btns = JSONArray()
            p.buttons.forEach { b ->
                btns.put(
                    JSONObject().put("id", b.id).put("label", b.label).put("enabled", b.enabled)
                        .put("x", b.x.toDouble()).put("y", b.y.toDouble()).put("size", b.sizeDp.toDouble())
                        .put("color", b.color).put("opacity", b.opacity.toDouble()).put("action", b.action.name)
                        .put("tx", b.tx.toDouble()).put("ty", b.ty.toDouble())
                        .put("tx2", b.tx2.toDouble()).put("ty2", b.ty2.toDouble())
                        .put("dur", b.durationMs).put("locked", b.locked)
                )
            }
            profiles.put(JSONObject().put("id", p.id).put("name", p.name).put("elements", els).put("buttons", btns))
        }
        return JSONObject().put("profiles", profiles).put("active", s.activeId)
            .put("host", s.serverHost).put("port", s.serverPort).put("onlyInGame", s.onlyInGame)
    }
}
