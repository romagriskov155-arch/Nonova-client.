package app.novaclient.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import app.novaclient.hud.HudStore
import app.novaclient.library.Kind
import app.novaclient.library.LibraryRepository

sealed interface Screen {
    data object Home : Screen
    data class Library(val kind: Kind) : Screen
    data object History : Screen
    data object Hud : Screen
    data object HudEditor : Screen
    data object Settings : Screen
}

@Composable
fun App() {
    val context = LocalContext.current
    val repo = remember { LibraryRepository(context.applicationContext) }
    val hudStore = remember { HudStore(context.applicationContext) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    BackHandler(enabled = screen != Screen.Home) {
        screen = if (screen == Screen.HudEditor) Screen.Hud else Screen.Home
    }

    when (val s = screen) {
        Screen.Home -> MainScreen(onOpen = { screen = it })
        is Screen.Library -> LibraryScreen(s.kind, repo, onBack = { screen = Screen.Home })
        Screen.History -> HistoryScreen(repo, onBack = { screen = Screen.Home })
        Screen.Hud -> HudScreen(hudStore, onBack = { screen = Screen.Home }, onEditor = { screen = Screen.HudEditor })
        Screen.HudEditor -> HudEditorScreen(hudStore, onBack = { screen = Screen.Hud })
        Screen.Settings -> SettingsScreen(hudStore, repo, onBack = { screen = Screen.Home })
    }
}
