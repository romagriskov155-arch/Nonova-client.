package app.novaclient.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import app.novaclient.minecraft.Minecraft
import app.novaclient.minecraft.MinecraftStatus

private data class Section(val title: String, val note: String)

private val sections = listOf(
    Section("Моды", "Этап 2"),
    Section("Текстуры", "Этап 2"),
    Section("Шейдеры", "Этап 2"),
    Section("Миры", "Этап 2"),
    Section("HUD", "Этап 3"),
    Section("Настройки", "Этап 5"),
)

@Composable
fun MainScreen() {
    val context = LocalContext.current
    var status by remember { mutableStateOf(Minecraft.detect(context)) }
    var error by remember { mutableStateOf<String?>(null) }

    // Вернулись из игры или магазина: перепроверяем установку и версию.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { status = Minecraft.detect(context) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(NovaNavy, NovaBlack)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Nova Client", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = NovaText)
        Text("Клиент для Minecraft Bedrock", color = NovaMuted)

        StatusCard(status)

        if (status.installed && status.canLaunch) {
            Button(
                onClick = {
                    error = Minecraft.launch(context).exceptionOrNull()?.let { "Не удалось запустить игру: ${it.message}" }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Запустить Minecraft", fontWeight = FontWeight.SemiBold)
            }
        } else {
            OutlinedButton(
                onClick = { Minecraft.openStore(context) },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
            ) { Text("Открыть Minecraft в магазине") }
        }

        error?.let { Text(it, color = NovaBad) }

        Text("Разделы", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = NovaText)
        sections.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { SectionCard(it, Modifier.weight(1f)) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text(
            "Разделы появятся по мере разработки; недоступные пока не нажимаются.",
            color = NovaMuted, fontSize = 12.sp,
        )
    }
}

@Composable
private fun StatusCard(status: MinecraftStatus) {
    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = NovaCard),
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).background(if (status.installed) NovaOk else NovaBad, CircleShape))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    if (status.installed) "Minecraft найден" else "Minecraft не установлен",
                    fontWeight = FontWeight.SemiBold, color = NovaText,
                )
                if (status.installed) {
                    Text(
                        "Версия ${status.versionName ?: "неизвестна"} (сборка ${status.versionCode})",
                        color = NovaMuted, fontSize = 13.sp,
                    )
                } else {
                    Text("Установите оригинальную игру из магазина", color = NovaMuted, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun SectionCard(section: Section, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.alpha(0.55f),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = NovaCard),
    ) {
        Column(Modifier.padding(16.dp).fillMaxWidth()) {
            Text(section.title, fontWeight = FontWeight.SemiBold, color = NovaText)
            Text(section.note, color = NovaCyan, fontSize = 12.sp)
        }
    }
}
