package app.novaclient.minecraft

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build

data class MinecraftStatus(
    val installed: Boolean,
    val versionName: String? = null,
    val versionCode: Long? = null,
    val canLaunch: Boolean = false,
)

/** Работа с оригинальным установленным Minecraft Bedrock. Ничего не скачивает и не изменяет. */
object Minecraft {
    const val PACKAGE = "com.mojang.minecraftpe"

    fun detect(context: Context): MinecraftStatus {
        val pm = context.packageManager
        return try {
            val info = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(PACKAGE, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION") pm.getPackageInfo(PACKAGE, 0)
            }
            MinecraftStatus(
                installed = true,
                versionName = info.versionName,
                versionCode = info.longVersionCode,
                canLaunch = pm.getLaunchIntentForPackage(PACKAGE) != null,
            )
        } catch (e: PackageManager.NameNotFoundException) {
            MinecraftStatus(installed = false)
        }
    }

    fun launch(context: Context): Result<Unit> = runCatching {
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE)
            ?: error("Не удалось получить способ запуска Minecraft")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    /** Открывает страницу официальной игры в магазине. */
    fun openStore(context: Context) {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PACKAGE"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(market)
        } catch (e: ActivityNotFoundException) {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$PACKAGE"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
